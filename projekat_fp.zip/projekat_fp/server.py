import socket
import threading
import tkinter
import random
from tkinter import *
from tkinter import font
import time
#1234567891
def konekcija(conn,adr):
    while True:
        print("Konektovali ste se na:", adr)
        piza = conn.recv(1024).decode()
        if not piza:
            return
        print("Vasa pica je:" + piza)
        br_porudzbine.set(br_porudzbine.get() + 1)
        vreme_1 = random.randint(1, 10)
        time = str(vreme_1)
        conn.send(time.encode())
        t2 = threading.Thread(target=vreme, args=(piza, vreme_1, conn)).start()
        br_porudzbine.set(br_porudzbine.get() + 1)

def fja():
    s1.listen(100)
    while True:
        conn, adr = s1.accept()
        t3 = threading.Thread(target=konekcija,args=(conn,adr)).start()
        br_porudzbine.set(br_porudzbine.get() + 1)

def vreme(piza,vreme_1,conn):
    var=StringVar(value=piza)
    var2 = StringVar(value=piza)
    l = Label(prozor, textvariable=var2, font=font_2).grid(row=br_porudzbine.get(), column=0)
    br_porudzbine.set(br_porudzbine.get() + 1)
    l1=Label(prozor,textvariable=var,font=font_1).grid(row=br_porudzbine.get(),column=0)
    while vreme_1>0:
        #piza=piza+vreme_1
        var.set("Narudzbina"+str(br_porudzbine.get())+"Vreme preostalo"+str(vreme_1))
        time.sleep(1)
        vreme_1-=1
    var2=StringVar(value="Narudzbina"+str(br_porudzbine.get()))
    var.set(' '*50)
    l2 = Label(prozor, textvariable=var2, font=font_1).grid(row=br_porudzbine.get(), column=1)
    br_porudzbine.set(br_porudzbine.get()+1)


s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = socket.gethostname()
port = 9997
s1.bind((host, port))
print("Server pokrenut...")
brojac = 0
lista_tredova = []
prozor = tkinter.Tk()
piza = StringVar()
br_porudzbine=IntVar()
font_1 = font.Font(prozor, family="Verdana", size=16)
font_2 = font.Font(prozor, family="Verdana", size=7)
prozor.geometry("650x500")
t1 = threading.Thread(target=fja).start()
prozor.mainloop()