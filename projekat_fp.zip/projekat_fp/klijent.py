import time
import threading
import tkinter
import socket
import pickle
from tkinter import *
from tkinter import messagebox
from tkinter import font

def posalji_2():
    Piza = [""] * 10
    Piza[0] = "Velicina pice je:"
    Piza[1] = "Napomena: " + napomena.get()
    if(str(adresa.get()).isdigit()):
        messagebox.showinfo("Greska", "Pogresan format za adresu")
        return
    Piza[2] = "Adresa je: " + adresa.get()
    if(not(str(broj_tel.get()).isdigit()) or len(broj_tel.get())!=10):
        messagebox.showinfo("Greska","Pogresan format za broj telefona")
        return
    Piza[3] = "Broj telefona je: " + broj_tel.get()
    Piza[4] = "Vrsta pice je:"
    Piza[5] = "Dodaci su: "
    Piza[6] = "Nacin placanja je: "
    if vel_pice.get() == 1:
        Piza[0] += "25"
    if vel_pice.get() == 2:
        Piza[0] += "32"
    if vel_pice.get() == 3:
        Piza[0] += "50"
    if vel_pice.get() == 4:
        Piza[0] += "120"
    if vrsta_pice.get() == 1:
        Piza[4] += "Margarita"
    if vrsta_pice.get() == 2:
        Piza[4] += "Funghi"
    if vrsta_pice.get() == 3:
        Piza[4] += "Quatro Stagione"
    if vrsta_pice.get() == 4:
        Piza[4] += "Vegetariana"
    if vrsta_pice.get() == 5:
        Piza[4] += "NovaPica123"
    if dodaci_kecap.get() == 1:
        Piza[5] += "Kecap "
    if dodaci_origano.get() == 1:
        Piza[5] += "Origano "
    if dodaci_majonez.get() == 1:
        Piza[5] += "Majonez "
    if nacin_placanja.get() == 1:
        Piza[6] += "Karticom"
    else:
        Piza[6] += "Novcem"
    piza3 = ''.join(Piza)
    s1.send(piza3.encode())
    vreme=s1.recv(1024).decode()
    messagebox.showinfo("vreme","Vase vreme za narudzbinu je:"+vreme+" sekundi")
def posalji():
    print("Poslato...")
    t2=threading.Thread(target=posalji_2).start()
s1=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host=socket.gethostname()
port=9997
prozor=tkinter.Tk()
s1.connect((host,port))
prozor.geometry("650x500")
vel_pice=IntVar()
vrsta_pice=IntVar()
dodaci_kecap=IntVar()
dodaci_majonez=IntVar()
dodaci_origano=IntVar()
nacin_placanja=IntVar()
adresa=StringVar()
broj_tel=StringVar()
napomena=StringVar()
font_1=font.Font(prozor,family="Verdana",size=16)
labela1=Label(prozor,text="Narucite picu",font=font_1).grid(row=0,column=0)
labela2=Label(prozor,text="Izaberite velicinu pice:",font=font_1).grid(row=1,column=0)
radio_d1=Radiobutton(prozor,text="25",variable=vel_pice,value=1).grid(row=2,column=0)
radio_d2=Radiobutton(prozor,text="32",variable=vel_pice,value=2).grid(row=3,column=0)
radio_d3=Radiobutton(prozor,text="50",variable=vel_pice,value=3).grid(row=4,column=0)
radio_d4=Radiobutton(prozor,text="120",variable=vel_pice,value=4).grid(row=5,column=0)
labela3=Label(prozor,text="Izaberite vrstu pice:",font=font_1).grid(row=6,column=0)
radio_d4=Radiobutton(prozor,text="Margarita",variable=vrsta_pice,value=1).grid(row=7,column=0)
radio_d5=Radiobutton(prozor,text="Funghi",variable=vrsta_pice,value=2).grid(row=8,column=0)
radio_d6=Radiobutton(prozor,text="Quatro Stagione",variable=vrsta_pice,value=3).grid(row=9,column=0)
radio_d7=Radiobutton(prozor,text="Vegetariana",variable=vrsta_pice,value=4).grid(row=10,column=0)
radio_d8=Radiobutton(prozor,text="NovaPica123",variable=vrsta_pice,value=5).grid(row=11,column=0)
labela4=Label(prozor,text="Izaberite dodatke:",font=font_1).grid(row=12,column=0)
chek_1=Checkbutton(prozor,text="Kecap",variable=dodaci_kecap,onvalue=1,offvalue=0).grid(row=13,column=0)
chek_2=Checkbutton(prozor,text="Majonez",variable=dodaci_majonez,onvalue=1,offvalue=0).grid(row=14,column=0)
chek_3=Checkbutton(prozor,text="Origano",variable=dodaci_origano,onvalue=1,offvalue=0).grid(row=15,column=0)
labela5=Label(prozor,text="Izaberite nacin placanja:",font=font_1).grid(row=0,column=1)
radio_d8=Radiobutton(prozor,text="Karticom",variable=nacin_placanja,value=1).grid(row=1,column=1)
radio_d9=Radiobutton(prozor,text="Novcem",variable=nacin_placanja,value=2).grid(row=2,column=1)
labela5=Label(prozor,text="Uneti adresu ovde",font=font_1).grid(row=3,column=1)
tb=Entry(prozor,textvariable=adresa).grid(row=4,column=1)
labela6=Label(prozor,text="Uneti br tel ovde",font=font_1).grid(row=5,column=1)
tb2=Entry(prozor,textvariable=broj_tel).grid(row=6,column=1)
labela7=Label(prozor,text="Napomena",font=font_1).grid(row=8,column=1)
text=Text(prozor,height=5,width=20,bd="0px").grid(row=10,column=1)
dugme=Button(prozor,text="Posalji serveru",command=posalji).grid(row=11,column=1)
prozor.mainloop()
